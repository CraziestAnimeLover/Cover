export const referralValidation = {};

