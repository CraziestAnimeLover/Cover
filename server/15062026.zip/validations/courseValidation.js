export const courseValidation = {};

